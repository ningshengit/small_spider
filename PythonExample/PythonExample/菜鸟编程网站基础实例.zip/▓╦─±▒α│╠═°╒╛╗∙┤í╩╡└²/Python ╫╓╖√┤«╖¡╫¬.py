 
实例 1：使用字符串切片 

str='Runoob'
print(str[::-1])
 
实例 2：使用 reversed()  

str='Runoob'
print(''.join(reversed(str)))
