 
实例 

# -*- coding: UTF-8 -*-
 
# Filename : test.py
# author by : www.runoob.com
 
# 生成 0 ~ 9 之间的随机数
 
# 导入 random(随机数) 模块
import random
 
print(random.randint(0,9))
