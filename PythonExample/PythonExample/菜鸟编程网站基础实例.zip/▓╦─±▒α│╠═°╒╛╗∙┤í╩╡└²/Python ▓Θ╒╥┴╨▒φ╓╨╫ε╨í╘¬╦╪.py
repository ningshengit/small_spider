实例 1 
list1 = [10, 20, 4, 45, 99] 
  
list1.sort() 
  
print("最小元素为:", *list1[:1]) 
实例 2：使用 min() 方法 
list1 = [10, 20, 1, 45, 99] 
  
print("最小元素为:", min(list1)) 
