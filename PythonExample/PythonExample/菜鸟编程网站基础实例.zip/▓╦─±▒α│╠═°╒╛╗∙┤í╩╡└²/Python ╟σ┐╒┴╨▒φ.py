实例 1 
RUNOOB = [6, 0, 4, 1] 
print('清空前:', RUNOOB)  
  
RUNOOB.clear()
print('清空后:', RUNOOB)  
