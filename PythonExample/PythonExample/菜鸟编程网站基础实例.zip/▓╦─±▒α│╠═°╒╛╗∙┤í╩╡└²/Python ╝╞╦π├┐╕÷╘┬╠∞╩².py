 
实例(Python 3.0+) 

#!/usr/bin/python3
# author by : www.runoob.com
 
import calendar
monthRange = calendar.monthrange(2016,9)
print(monthRange)

